import cv2
import numpy as np
import pymysql
import socket
import json
from datetime import datetime
import time
import sys
import os
import locale
import datetime as dt
import struct
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QPushButton, QLabel, QLineEdit, QMessageBox, QTabWidget,
                             QComboBox, QStackedWidget, QSizePolicy, QGridLayout, QGroupBox)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QSize, QThread
from PyQt5.QtGui import QImage, QPixmap, QFont, QColor, QPalette
import serial  # 导入串口库
import threading  # 新增：用于短信发送线程

# System environment settings
if sys.platform.startswith('win'):
    os.system('chcp 65001')
    sys.stdout.reconfigure(encoding='utf-8')
    os.environ["PYTHONIOENCODING"] = "utf-8"
    locale.setlocale(locale.LC_ALL, 'english')
else:
    locale.setlocale(locale.LC_ALL, 'en_US.utf8')


class SerialWorker(QThread):
    f_received = pyqtSignal()

    def __init__(self, serial_port):
        super().__init__()
        self.serial_port = serial_port
        self.running = True

    def run(self):
        while self.running:
            if self.serial_port and self.serial_port.in_waiting > 0:
                try:
                    data = self.serial_port.read(1)
                    if data == b'f':
                        print("✅✅✅✅✅✅✅✅ Received 'f' from serial port 1")
                        self.f_received.emit()
                except Exception as e:
                    print(f"❌ Error reading from serial port 1: {e}")
            time.sleep(0.01)  # 避免过度占用CPU

    def stop(self):
        self.running = False


class PCBScannerClient:
    def __init__(self):
        # ===================== Database Configuration =====================
        self.db_config = {
            'host': '192.168.201.115',
            'user': 'remote_user',
            'password': '123456',
            'database': 'loognson_pcb',
            'port': 3306,
            'charset': 'utf8mb4',
            'cursorclass': pymysql.cursors.DictCursor
        }

        # ===================== 串口配置 =====================
        # 串口1用于发送合格/不合格信号和接收'f'
        self.serial_port1 = None
        # 串口2用于发送启动信号's'
        self.serial_port2 = None
        # 新增：短信通知串口
        self.sms_serial_port = None
        self.serial_baudrate = 115200  # 波特率改为115200以匹配uart1.py
        self.initialize_serial_ports()  # 初始化串口
        self.last_pcb_id_for_serial = None  # 上次发送信号的PCB ID
        self.last_serial_result = None  # 上次发送的信号结果(合格/不合格)
        self.serial_worker = None
        self.waiting_for_f = False  # 新增：等待接收'f'信号状态
        # 新增：记录已发送短信的PCB ID
        self.sent_sms_pcbs = set()

        # ===================== Network Configuration =====================
        self.server_ip = '192.168.201.115'  # Server IP address
        self.server_port = 5000  # Video sending port
        self.result_port = 5001  # Result receiving port
        self.original_img_port = 5006  # 原始图片接收端口
        self.processed_img_port = 5007  # 处理后图片接收端口

        # 帧率控制
        self.frame_interval = 0.1  # 10fps (0.1秒/帧)
        self.last_send_time = 0

        # Create UDP socket
        self.udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Create result receiving socket
        self.result_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.result_socket.bind(('0.0.0.0', self.result_port))
        self.result_socket.settimeout(0.1)

        # 创建原始图片接收套接字
        self.original_img_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.original_img_socket.bind(('0.0.0.0', self.original_img_port))
        self.original_img_socket.settimeout(0.1)

        # 创建处理后图片接收套接字
        self.processed_img_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.processed_img_socket.bind(('0.0.0.0', self.processed_img_port))
        self.processed_img_socket.settimeout(0.1)

        # ===================== Camera Configuration =====================
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            print("❌❌❌❌❌❌❌❌ Failed to open camera")
            self.cap = None
        else:
            # 降低分辨率以减少传输数据量
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 480)  # 原640
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)  # 原480

        # ===================== State Variables =====================
        self.current_pcb_id = None  # Current PCB ID
        self.pcb_info = None  # Current PCB info
        self.defect_counts = None  # Defect counts
        self.last_scan_time = 0  # Last scan time
        self.scan_cooldown = 3  # Scan cooldown (seconds)
        self.last_qr_result = None  # Last QR result
        self.db = None  # Database connection
        self.image_paths = {}  # Image paths
        self.last_db_update = 0  # Last database update time
        self.db_refresh_interval = 1  # Refresh database every 1 second
        self.is_qualified = None  # PCB是否合格
        self.serial_lock = False  # 串口操作锁

        # ===================== 图片存储配置 =====================
        # 创建合格和不合格PCB的文件夹结构
        self.qualified_dir = "qualified_PCB"
        self.unqualified_dir = "unqualified_PCB"

        # 创建主文件夹
        os.makedirs(self.qualified_dir, exist_ok=True)
        os.makedirs(self.unqualified_dir, exist_ok=True)

        # 在每个主文件夹下创建original和processed子文件夹
        self.qualified_original_dir = os.path.join(self.qualified_dir, "original")
        self.qualified_processed_dir = os.path.join(self.qualified_dir, "processed")
        self.unqualified_original_dir = os.path.join(self.unqualified_dir, "original")
        self.unqualified_processed_dir = os.path.join(self.unqualified_dir, "processed")

        os.makedirs(self.qualified_original_dir, exist_ok=True)
        os.makedirs(self.qualified_processed_dir, exist_ok=True)
        os.makedirs(self.unqualified_original_dir, exist_ok=True)
        os.makedirs(self.unqualified_processed_dir, exist_ok=True)

        # 启动串口监听线程
        if self.serial_port1:
            self.serial_worker = SerialWorker(self.serial_port1)
            self.serial_worker.f_received.connect(self.handle_f_received)
            self.serial_worker.start()

    def initialize_serial_ports(self):
        """初始化串口连接"""
        try:
            # 尝试打开串口1（用于发送合格/不合格信号和接收'f'） - 对应/dev/ttyS1
            self.serial_port1 = serial.Serial('/dev/ttyS1', self.serial_baudrate, timeout=0.1)
            print("✅ Serial port 1 (/dev/ttyS1) opened successfully")
        except serial.SerialException as e:
            print(f"❌ Failed to open serial port 1 (/dev/ttyS1): {e}")
            self.serial_port1 = None

        try:
            # 尝试打开串口2（用于发送启动信号's'） - 对应/dev/ttyS2
            self.serial_port2 = serial.Serial('/dev/ttyS2', self.serial_baudrate, timeout=0.1)
            print("✅ Serial port 2 (/dev/ttyS2) opened successfully")
        except serial.SerialException as e:
            print(f"❌ Failed to open serial port 2 (/dev/ttyS2): {e}")
            self.serial_port2 = None

        # 新增：初始化短信通知串口
        try:
            # 尝试打开短信通知串口（/dev/ttyS3）
            self.sms_serial_port = serial.Serial('/dev/ttyS3', self.serial_baudrate, timeout=5)
            print("✅ SMS serial port (/dev/ttyS3) opened successfully")
        except serial.SerialException as e:
            print(f"❌ Failed to open SMS serial port (/dev/ttyS3): {e}")
            self.sms_serial_port = None

    def handle_f_received(self):
        """处理接收到'f'信号"""
        # 清除等待状态
        self.waiting_for_f = False
        print("✅ 'f' received, clearing waiting state")

        if self.serial_port2:
            try:
                self.serial_port2.write(b's')
                print("📢📢📢📢📢📢📢📢 Sent 's' to serial port 2")
            except serial.SerialException as e:
                print(f"❌ Failed to send 's' to serial port 2: {e}")
        else:
            print("⚠️ Serial port 2 not available, cannot send 's'")

    def send_serial_signals(self):
        """发送串口信号"""
        # 如果正在处理串口信号，则跳过
        if self.serial_lock:
            return

        # 检查是否需要发送新信号
        should_send = False

        # 如果是新PCB且结果已确定
        if self.current_pcb_id is not None and self.is_qualified is not None:
            # 如果是新PCB
            if self.current_pcb_id != self.last_pcb_id_for_serial:
                should_send = True
                print(f"🔔 New PCB detected: {self.current_pcb_id}, sending signal")
            # 如果是同一个PCB但结果改变了
            elif self.last_serial_result != self.is_qualified:
                should_send = True
                print(f"🔄 PCB {self.current_pcb_id} result changed, sending new signal")

        # 发送合格/不合格信号到串口1
        if should_send and self.serial_port1:
            try:
                # 设置串口操作锁
                self.serial_lock = True

                if self.is_qualified:
                    self.serial_port1.write(b'1')  # 合格
                    print(f"📢 Sent '1' (qualified) to serial port 1 for PCB {self.current_pcb_id}")
                    # 设置等待状态
                    self.waiting_for_f = True
                    print("🕒 Waiting for 'f' signal...")
                else:
                    self.serial_port1.write(b'2')  # 不合格
                    print(f"📢 Sent '2' (unqualified) to serial port 1 for PCB {self.current_pcb_id}")
                    # 不合格不需要等待'f'
                    self.waiting_for_f = False

                # 更新最后发送的PCB和结果
                self.last_pcb_id_for_serial = self.current_pcb_id
                self.last_serial_result = self.is_qualified

                # 不需要在这里等待，由串口监听线程处理
            except serial.SerialException as e:
                print(f"❌ Failed to send signal to serial port 1: {e}")
                # 发生错误时释放锁
                self.serial_lock = False
            finally:
                # 无论发送是否成功，都释放锁
                self.serial_lock = False

    # 新增：发送不合格通知短信
    def send_unqualified_sms(self, pcb_id, defect_counts):
        """通过串口发送不合格PCB通知"""
        # 确保只发送一次
        if pcb_id in self.sent_sms_pcbs:
            return

        if self.sms_serial_port is None:
            print("⚠️ SMS serial port not available, cannot send notification")
            return

        try:
            # 构造短信内容
            defect_info = ", ".join([f"{defect}: {count}" for defect, count in defect_counts.items() if count > 0])
            message = f"Unqualified PCB detected. PCB ID: {pcb_id}. Defects: {defect_info}"
            print(f"📩 Preparing to send SMS: {message}")

            # 在独立线程中发送短信，避免阻塞主线程
            def sms_thread():
                try:
                    # 1. 发送AT测试指令
                    self.sms_serial_port.write(b'AT\r\n')
                    time.sleep(1)
                    response = self.sms_serial_port.read(self.sms_serial_port.in_waiting).decode(errors='ignore')
                    print(f"AT response: {response.strip()}")

                    # 2. 设置短信文本模式
                    self.sms_serial_port.write(b'AT+CMGF=1\r\n')
                    time.sleep(1)
                    response = self.sms_serial_port.read(self.sms_serial_port.in_waiting).decode(errors='ignore')
                    print(f"AT+CMGF response: {response.strip()}")

                    # 3. 设置接收号码
                    phone_number = "18792172978"  # 替换为实际接收号码
                    self.sms_serial_port.write(f'AT+CMGS="{phone_number}"\r\n'.encode())
                    time.sleep(1)
                    response = self.sms_serial_port.read(self.sms_serial_port.in_waiting).decode(errors='ignore')
                    print(f"AT+CMGS response: {response.strip()}")

                    # 4. 发送短信内容
                    # 只发送消息内容，不包含AT指令
                    self.sms_serial_port.write(message.encode() + b'\x1A')  # \x1A 是Ctrl+Z结束符
                    time.sleep(3)  # 等待发送完成

                    # 5. 读取最终响应
                    final_response = self.sms_serial_port.read(self.sms_serial_port.in_waiting).decode(errors='ignore')
                    print(f"SMS sending result: {final_response.strip()}")

                    # 标记为已发送
                    self.sent_sms_pcbs.add(pcb_id)
                    print(f"✅ SMS notification sent for PCB {pcb_id}")
                except Exception as e:
                    print(f"❌ Error sending SMS: {e}")

            # 启动短信发送线程
            threading.Thread(target=sms_thread, daemon=True).start()

        except Exception as e:
            print(f"❌ Error preparing SMS: {e}")

    def connect_db(self):
        """Connect to database"""
        try:
            self.db = pymysql.connect(**self.db_config)
            print("✅ Database connection successful")
            return True
        except pymysql.Error as e:
            print(f"❌❌❌❌❌❌❌❌ Database connection failed: {e}")
            return False

    def get_pcb_info(self, pcb_id):
        """Get PCB information from database"""
        try:
            with self.db.cursor() as cursor:
                sql = """
                      SELECT pcb_id, \
                             production_time, \
                             inspection_time, \
                             missing_holes, \
                             mouse_bites, \
                             open_circuits, \
                             short_circuits, \
                             stray_signals, \
                             spurious_copper, \
                             is_qualified, \
                             actual_image_path, \
                             result_image_path, \
                             notes, \
                             last_updated
                      FROM pcb_inspection
                      WHERE pcb_id = %s \
                      """
                cursor.execute(sql, (pcb_id,))
                result = cursor.fetchone()

                if result:
                    # 不再在查询中格式化时间字段
                    return result
                return None
        except pymysql.Error as e:
            print(f"❌❌❌❌❌❌❌❌ PCB info query failed: {e}")
            return None

    def update_db(self, pcb_id, defect_counts, original_path, processed_path):
        """Update defect counts and image paths in database"""
        try:
            with self.db.cursor() as cursor:
                # 确定PCB是否合格（任何缺陷计数>0即为不合格）
                is_qualified = all(count == 0 for count in defect_counts.values())
                self.is_qualified = is_qualified  # 更新状态变量

                sql = """
                      UPDATE pcb_inspection
                      SET missing_holes     = %s,
                          mouse_bites       = %s,
                          open_circuits     = %s,
                          short_circuits    = %s,
                          stray_signals     = %s,
                          spurious_copper   = %s,
                          actual_image_path = %s,
                          result_image_path = %s,
                          is_qualified      = %s,
                          inspection_time   = NOW(),
                          last_updated      = NOW()
                      WHERE pcb_id = %s \
                      """
                cursor.execute(sql, (
                    defect_counts['missing_holes'],
                    defect_counts['mouse_bites'],
                    defect_counts['open_circuits'],
                    defect_counts['short_circuits'],
                    defect_counts['stray_signals'],
                    defect_counts['spurious_copper'],
                    original_path,
                    processed_path,
                    is_qualified,
                    pcb_id
                ))
                self.db.commit()

                # 新增：如果不合格且是第一次检测到，发送短信通知
                if not is_qualified and pcb_id not in self.sent_sms_pcbs:
                    self.send_unqualified_sms(pcb_id, defect_counts)

            return True
        except pymysql.Error as e:
            print(f"❌❌❌❌❌❌❌❌ Database update failed: {e}")
            return False

    def send_frame(self, frame):
        """Send video frame to server"""
        current_time = time.time()
        # 控制发送帧率
        if current_time - self.last_send_time < self.frame_interval:
            return

        self.last_send_time = current_time

        try:
            # Compress image (降低质量)
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 60]  # 降低质量到60
            _, buffer = cv2.imencode('.jpg', frame, encode_param)
            data = buffer.tobytes()

            # Send data
            self.udp_socket.sendto(data, (self.server_ip, self.server_port))
        except Exception as e:
            print(f"❌❌❌❌❌❌❌❌ Failed to send video frame: {e}")

    def check_results(self):
        """Check for results from server"""
        try:
            data, addr = self.result_socket.recvfrom(65536)
            result = json.loads(data.decode('utf-8'))

            current_time = time.time()

            # Check cooldown
            if current_time - self.last_scan_time > self.scan_cooldown:
                self.last_scan_time = current_time

                pcb_id = result.get('pcb_id')
                if pcb_id and 1 <= pcb_id <= 20:
                    self.current_pcb_id = pcb_id

                    # Update defect counts
                    defect_counts = result.get('defects', {})
                    if defect_counts:
                        self.defect_counts = defect_counts
                        # 确定PCB是否合格（任何缺陷计数>0即为不合格）
                        self.is_qualified = all(count == 0 for count in defect_counts.values())

                # Save last result
                self.last_qr_result = result

        except socket.timeout:
            pass  # No data received is normal
        except Exception as e:
            print(f"❌❌❌❌❌❌❌❌ Failed to receive detection results: {e}")

    def check_original_images(self):
        """检查并接收原始图片"""
        try:
            data, addr = self.original_img_socket.recvfrom(65536 * 5)

            # 提取PCB ID (前4个字节)
            pcb_id = struct.unpack('!I', data[:4])[0]

            # 剩余部分是图片数据
            img_data = data[4:]

            # 解析图片
            np_data = np.frombuffer(img_data, dtype=np.uint8)
            img = cv2.imdecode(np_data, cv2.IMREAD_COLOR)

            if img is not None:
                # 根据PCB是否合格选择保存路径
                if self.is_qualified:
                    save_dir = self.qualified_original_dir
                else:
                    save_dir = self.unqualified_original_dir

                # 保存图片到本地
                filename = f"PCB{pcb_id}.jpg"
                original_path = os.path.join(save_dir, filename)
                cv2.imwrite(original_path, img)
                print(f"💾💾💾💾 Saved original image for PCB {pcb_id} at {original_path}")

                # 如果已经收到检测结果，更新数据库
                if self.defect_counts:
                    # 确保有处理后图片路径或设为None
                    processed_path = self.image_paths.get('processed') if self.image_paths else None
                    self.update_db(pcb_id, self.defect_counts, original_path, processed_path)
                    print(f"📝📝📝📝 Updated database with original image path for PCB {pcb_id}")

                # 保存路径用于后续更新
                if 'original' not in self.image_paths:
                    self.image_paths['original'] = original_path
                else:
                    self.image_paths['original'] = original_path

            else:
                print(f"❌❌❌❌ Failed to decode original image for PCB {pcb_id}")

        except socket.timeout:
            pass
        except Exception as e:
            print(f"❌❌❌❌❌❌❌❌ Error receiving original image: {e}")

    def check_processed_images(self):
        """检查并接收处理后图片"""
        try:
            data, addr = self.processed_img_socket.recvfrom(65536 * 5)

            # 提取PCB ID (前4个字节)
            pcb_id = struct.unpack('!I', data[:4])[0]

            # 剩余部分是图片数据
            img_data = data[4:]

            # 解析图片
            np_data = np.frombuffer(img_data, dtype=np.uint8)
            img = cv2.imdecode(np_data, cv2.IMREAD_COLOR)

            if img is not None:
                # 根据PCB是否合格选择保存路径
                if self.is_qualified:
                    save_dir = self.qualified_processed_dir
                else:
                    save_dir = self.unqualified_processed_dir

                # 保存图片到本地
                filename = f"PCB{pcb_id}.jpg"
                processed_path = os.path.join(save_dir, filename)
                cv2.imwrite(processed_path, img)
                print(f"💾💾💾💾 Saved processed image for PCB {pcb_id} at {processed_path}")

                # 如果已经收到检测结果，更新数据库
                if self.defect_counts:
                    # 确保有原始图片路径或设为None
                    original_path = self.image_paths.get('original') if self.image_paths else None
                    self.update_db(pcb_id, self.defect_counts, original_path, processed_path)
                    print(f"📝📝📝📝 Updated database with processed image path for PCB {pcb_id}")

                # 保存路径用于后续更新
                if 'processed' not in self.image_paths:
                    self.image_paths['processed'] = processed_path
                else:
                    self.image_paths['processed'] = processed_path

            else:
                print(f"❌❌❌❌ Failed to decode processed image for PCB {pcb_id}")

        except socket.timeout:
            pass
        except Exception as e:
            print(f"❌❌❌❌❌❌❌❌ Error receiving processed image: {e}")

    def refresh_db_info(self):
        """Refresh PCB info from database periodically"""
        current_time = time.time()
        if current_time - self.last_db_update > self.db_refresh_interval:
            self.last_db_update = current_time

            if self.current_pcb_id and hasattr(self, 'db') and self.db.open:
                self.pcb_info = self.get_pcb_info(self.current_pcb_id)

    def format_datetime(self, dt_value):
        """Format datetime value for display"""
        if not dt_value:
            return "N/A"

        if isinstance(dt_value, dt.datetime):
            return dt_value.strftime('%Y-%m-%d %H:%M')
        elif isinstance(dt_value, str):
            # 如果已经是字符串，尝试解析并重新格式化
            try:
                parsed_dt = dt.datetime.strptime(dt_value, '%Y-%m-%d %H:%M:%S')
                return parsed_dt.strftime('%Y-%m-%d %H:%M')
            except:
                return dt_value
        else:
            return str(dt_value)

    def get_unqualified_images(self):
        """获取不合格PCB的处理后图片路径"""
        unqualified_dir = os.path.join(self.unqualified_dir, "processed")
        if os.path.exists(unqualified_dir):
            images = [f for f in os.listdir(unqualified_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            return [os.path.join(unqualified_dir, img) for img in images]
        return []


class WelcomeScreen(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        self.setWindowTitle('工业流水线PCB分拣系统')
        self.setFixedSize(800, 480)  # 固定窗口大小

        # 设置背景颜色
        self.setStyleSheet("""
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                          stop:0 #f5f7fa, stop:1 #c3cfe2);
            """)

        # 主布局
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.setContentsMargins(150, 0, 0, 0)  # 左边距100，右边距50

        # 标题
        title_label = QLabel('工业流水线PCB分拣系统')
        title_label.setStyleSheet("""
                QLabel {
                    font-size: 46px;
                    font-weight: bold;
                    color: #2c3e50;
                    font-family: 'Microsoft YaHei';
                }
            """)
        title_label.setAlignment(Qt.AlignCenter)

        # # 学校名称
        # school_label = QLabel('西安电子科技大学')
        # school_label.setStyleSheet('font-size: 24px; color: #555;')
        # school_label.setAlignment(Qt.AlignCenter)

        # 团队名称
        team_label = QLabel('无敌龙芯大王')
        team_label.setStyleSheet("""
                QLabel {
                    font-size: 36px;
                    color: #7f8c8d;
                    font-family: 'Microsoft YaHei';
                    font-style: italic;
                    margin-bottom: 30px;
                }
            """)
        team_label.setAlignment(Qt.AlignCenter)

        # 按钮布局
        button_layout = QHBoxLayout()
        button_layout.setSpacing(30)
        button_layout.setContentsMargins(50, 0, 50, 0)

        # 登录按钮
        login_btn = QPushButton('登录')
        login_btn.setStyleSheet('''
                QPushButton {
                    font-size: 24px;
                    font-family: 'Microsoft YaHei';
                    background-color: #2ecc71;
                    color: white;
                    border: none;
                    padding: 15px 32px;
                    text-align: center;
                    border-radius: 8px;
                    min-width: 200px;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
                QPushButton:pressed {
                    background-color: #1a5276;
                }
            ''')
        login_btn.setFixedSize(200, 80)
        login_btn.clicked.connect(self.parent().show_login_screen)

        # 退出按钮
        exit_btn = QPushButton('退出')
        exit_btn.setStyleSheet('''
                QPushButton {
                    font-size: 24px;
                    font-family: 'Microsoft YaHei';
                    background-color: #e74c3c;
                    color: white;
                    border: none;
                    padding: 15px 32px;
                    text-align: center;
                    border-radius: 8px;
                    min-width: 200px;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                }
                QPushButton:pressed {
                    background-color: #922b21;
                }
            ''')
        exit_btn.setFixedSize(200, 80)
        exit_btn.clicked.connect(QApplication.instance().quit)

        button_layout.addWidget(login_btn)
        button_layout.addWidget(exit_btn)

        # 添加到主布局
        main_layout.addStretch(1)
        main_layout.addWidget(title_label)
        main_layout.addWidget(team_label)
        main_layout.addStretch(1)
        main_layout.addLayout(button_layout)
        main_layout.addStretch(1)

        self.setLayout(main_layout)


class LoginScreen(QWidget):
    def __init__(self, main_window, parent=None):
        super().__init__(parent)
        self.main_window = main_window  # 保存MainWindow引用
        self.initUI()

    def initUI(self):
        self.setWindowTitle('登录')
        self.setFixedSize(800, 480)  # 固定窗口大小

        # 设置背景颜色
        self.setStyleSheet("""
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                                          stop:0 #f5f7fa, stop:1 #c3cfe2);
            """)

        # 主布局
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignCenter)
        main_layout.setContentsMargins(150, 0, 0, 0)  # 左边距100，右边距50

        # 标题
        title_label = QLabel('请输入密码')
        title_label.setStyleSheet("""
                QLabel {
                    font-size: 36px;
                    font-weight: bold;
                    color: #2c3e50;
                    font-family: 'Microsoft YaHei';
                    margin-bottom: 30px;
                }
            """)
        title_label.setAlignment(Qt.AlignCenter)

        # 密码输入框
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('密码')
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setStyleSheet('''
                QLineEdit {
                    font-size: 24px;
                    font-family: 'Microsoft YaHei';
                    padding: 12px;
                    border: 2px solid #bdc3c7;
                    border-radius: 8px;
                    min-width: 300px;
                    background: white;
                }
                QLineEdit:focus {
                    border: 2px solid #3498db;
                }
            ''')
        self.password_input.setAlignment(Qt.AlignCenter)

        # 按钮布局
        button_layout = QHBoxLayout()
        button_layout.setSpacing(30)
        button_layout.setContentsMargins(50, 30, 50, 0)

        # 登录按钮
        login_btn = QPushButton('登录')
        login_btn.setStyleSheet('''
                QPushButton {
                    font-size: 24px;
                    font-family: 'Microsoft YaHei';
                    background-color: #2ecc71;
                    color: white;
                    border: none;
                    padding: 15px 32px;
                    text-align: center;
                    border-radius: 8px;
                    min-width: 200px;
                }
                QPushButton:hover {
                    background-color: #2980b9;
                }
                QPushButton:pressed {
                    background-color: #1a5276;
                }
            ''')
        login_btn.setFixedSize(200, 80)
        login_btn.clicked.connect(self.check_password)

        # 退出按钮
        exit_btn = QPushButton('退出')
        exit_btn.setStyleSheet('''
                QPushButton {
                    font-size: 24px;
                    font-family: 'Microsoft YaHei';
                    background-color: #e74c3c;
                    color: white;
                    border: none;
                    padding: 15px 32px;
                    text-align: center;
                    border-radius: 8px;
                    min-width: 200px;
                }
                QPushButton:hover {
                    background-color: #c0392b;
                }
                QPushButton:pressed {
                    background-color: #922b21;
                }
            ''')
        exit_btn.setFixedSize(200, 80)
        exit_btn.clicked.connect(QApplication.instance().quit)

        button_layout.addWidget(login_btn)
        button_layout.addWidget(exit_btn)

        # 添加到主布局
        main_layout.addStretch(1)
        main_layout.addWidget(title_label)
        main_layout.addWidget(self.password_input)
        main_layout.addStretch(1)
        main_layout.addLayout(button_layout)
        main_layout.addStretch(1)

        self.setLayout(main_layout)

    def check_password(self):
        password = self.password_input.text()
        if password == '123456':
            self.main_window.show_main_screen()  # 使用保存的引用
        else:
            QMessageBox.warning(self, '错误', '密码错误，请重新输入！')
            self.password_input.clear()


class InfoPanel(QGroupBox):
    def __init__(self, parent=None):
        super().__init__("PCB检测信息", parent)
        self.initUI()

    def initUI(self):
        # 设置样式
        self.setStyleSheet("""
            QGroupBox {
                font-size: 16px;
                font-weight: bold;
                border: 2px solid #4CAF50;
                border-radius: 8px;
                margin-top: 1ex;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 5px;
                background-color: #4CAF50;
                color: white;
                border-radius: 4px;
            }
        """)

        # 使用网格布局
        layout = QGridLayout()
        layout.setSpacing(10)

        # 创建标签
        self.title_label = QLabel("PCB检测系统")
        self.title_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #4CAF50;")
        self.time_label = QLabel("时间: ")
        self.status_label = QLabel("状态: ")
        self.pcb_id_label = QLabel("PCB ID: ")
        self.prod_time_label = QLabel("生产时间: ")
        self.inspect_time_label = QLabel("检测时间: ")
        self.quality_label = QLabel("质量状态: ")
        self.defect_title_label = QLabel("缺陷统计:")
        self.missing_holes_label = QLabel("缺失孔洞: ")
        self.mouse_bites_label = QLabel("鼠咬: ")
        self.open_circuits_label = QLabel("开路: ")
        self.short_circuits_label = QLabel("短路: ")
        self.stray_signals_label = QLabel("杂散信号: ")
        self.spurious_copper_label = QLabel("多余铜箔: ")
        self.image_path_label = QLabel("图片路径: ")
        self.updated_label = QLabel("最后更新: ")
        self.waiting_label = QLabel("等待状态: ")

        # 添加标签到布局
        layout.addWidget(self.title_label, 0, 0, 1, 2)
        layout.addWidget(self.time_label, 1, 0)
        layout.addWidget(self.status_label, 2, 0)
        layout.addWidget(self.waiting_label, 3, 0)
        layout.addWidget(self.pcb_id_label, 4, 0)
        layout.addWidget(self.prod_time_label, 5, 0)
        layout.addWidget(self.inspect_time_label, 6, 0)
        layout.addWidget(self.quality_label, 7, 0)
        layout.addWidget(self.defect_title_label, 8, 0)
        layout.addWidget(self.missing_holes_label, 9, 0)
        layout.addWidget(self.mouse_bites_label, 10, 0)
        layout.addWidget(self.open_circuits_label, 11, 0)
        layout.addWidget(self.short_circuits_label, 12, 0)
        layout.addWidget(self.stray_signals_label, 13, 0)
        layout.addWidget(self.spurious_copper_label, 14, 0)
        layout.addWidget(self.image_path_label, 15, 0)
        layout.addWidget(self.updated_label, 16, 0)

        self.setLayout(layout)

    def update_info(self, scanner):
        """更新信息面板内容"""
        # 更新时间
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.time_label.setText(f"时间: {current_time}")

        # 更新状态
        if scanner.last_qr_result:
            pcb_id = scanner.last_qr_result.get('pcb_id', 'unknown')
            self.status_label.setText(f"状态: 检测到PCB {pcb_id}")
            self.status_label.setStyleSheet("color: green;")
        else:
            self.status_label.setText("状态: 等待二维码...")
            self.status_label.setStyleSheet("color: orange;")

        # 更新等待状态
        if scanner.waiting_for_f:
            self.waiting_label.setText("等待状态: 等待'f'信号...")
            self.waiting_label.setStyleSheet("color: orange;")
        else:
            self.waiting_label.setText("等待状态: 空闲")
            self.waiting_label.setStyleSheet("color: green;")

        # 更新PCB信息
        if scanner.pcb_info:
            self.pcb_id_label.setText(f"PCB ID: {scanner.pcb_info['pcb_id']}")

            # 生产时间
            prod_time = scanner.format_datetime(scanner.pcb_info.get('production_time', ''))
            self.prod_time_label.setText(f"生产时间: {prod_time}")

            # 检测时间
            insp_time = scanner.format_datetime(scanner.pcb_info.get('inspection_time', ''))
            self.inspect_time_label.setText(f"检测时间: {insp_time}")

            # 质量状态
            quality = "合格" if scanner.pcb_info.get('is_qualified', False) else "不合格"
            color = "green" if scanner.pcb_info.get('is_qualified', False) else "red"
            self.quality_label.setText(f"质量状态: {quality}")
            self.quality_label.setStyleSheet(f"color: {color}; font-weight: bold;")

            # 缺陷统计
            self.missing_holes_label.setText(f"缺失孔洞: {scanner.pcb_info.get('missing_holes', 0)}")
            self.mouse_bites_label.setText(f"鼠咬: {scanner.pcb_info.get('mouse_bites', 0)}")
            self.open_circuits_label.setText(f"开路: {scanner.pcb_info.get('open_circuits', 0)}")
            self.short_circuits_label.setText(f"短路: {scanner.pcb_info.get('short_circuits', 0)}")
            self.stray_signals_label.setText(f"杂散信号: {scanner.pcb_info.get('stray_signals', 0)}")
            self.spurious_copper_label.setText(f"多余铜箔: {scanner.pcb_info.get('spurious_copper', 0)}")

            # 图片路径
            if scanner.pcb_info.get('actual_image_path') and scanner.pcb_info.get('result_image_path'):
                orig_file = os.path.basename(scanner.pcb_info['actual_image_path'])
                proc_file = os.path.basename(scanner.pcb_info['result_image_path'])
                self.image_path_label.setText(f"图片路径: 原始: {orig_file}, 处理: {proc_file}")

            # 最后更新时间
            last_updated = scanner.format_datetime(scanner.pcb_info.get('last_updated', ''))
            self.updated_label.setText(f"最后更新: {last_updated}")
        else:
            self.pcb_id_label.setText("PCB ID: 无")
            self.quality_label.setText("质量状态: 未知")
            self.quality_label.setStyleSheet("color: gray;")


class InspectionTab(QWidget):
    def __init__(self, scanner, parent=None):
        super().__init__(parent)
        self.scanner = scanner
        self.initUI()

    def initUI(self):
        # 主布局 - 使用水平布局
        main_layout = QHBoxLayout()

        # 左侧：视频显示区域
        video_frame = QGroupBox("实时视频")
        video_frame.setStyleSheet("""
            QGroupBox {
                font-size: 16px;
                font-weight: bold;
                border: 2px solid #2196F3;
                border-radius: 8px;
                margin-top: 1ex;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 5px;
                background-color: #2196F3;
                color: white;
                border-radius: 4px;
            }
        """)
        video_layout = QVBoxLayout()
        self.video_label = QLabel()
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setStyleSheet('border: 1px solid #ddd; background-color: black;')
        self.video_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        video_layout.addWidget(self.video_label)
        video_frame.setLayout(video_layout)

        # 右侧：信息面板
        info_frame = QWidget()
        info_layout = QVBoxLayout()
        self.info_panel = InfoPanel()
        info_layout.addWidget(self.info_panel)
        info_layout.addStretch(1)
        info_frame.setLayout(info_layout)
        info_frame.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)

        # 添加到主布局
        main_layout.addWidget(video_frame, 2)  # 视频区域占2/3
        main_layout.addWidget(info_frame, 1)  # 信息区域占1/3

        self.setLayout(main_layout)

    def update_frame(self, frame):
        # 将OpenCV图像转换为Qt图像
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)

        # 缩放图像以适应标签大小
        scaled_pixmap = pixmap.scaled(self.video_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.video_label.setPixmap(scaled_pixmap)

        # 更新信息面板
        self.info_panel.update_info(self.scanner)


class ImageViewerTab(QWidget):
    def __init__(self, scanner, parent=None):
        super().__init__(parent)
        self.scanner = scanner
        self.initUI()

    def initUI(self):
        # 主布局
        main_layout = QVBoxLayout()

        # 图片选择下拉框
        self.image_combo = QComboBox()
        self.image_combo.setStyleSheet('font-size: 16px; padding: 5px;')
        self.image_combo.currentIndexChanged.connect(self.display_selected_image)

        # 刷新按钮
        refresh_btn = QPushButton('刷新图片列表')
        refresh_btn.setStyleSheet('''
            QPushButton {
                font-size: 16px;
                padding: 5px;
                background-color: #4CAF50;
                color: white;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
        ''')
        refresh_btn.clicked.connect(self.load_images)

        # 图片显示区域
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet('border: 1px solid #ddd; background-color: #f0f0f0;')
        self.image_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        # 控制面板布局
        control_layout = QHBoxLayout()
        control_layout.addWidget(QLabel('选择图片:'))
        control_layout.addWidget(self.image_combo, 1)
        control_layout.addWidget(refresh_btn)

        # 添加到主布局
        main_layout.addLayout(control_layout)
        main_layout.addWidget(self.image_label, 1)

        self.setLayout(main_layout)

        # 初始加载图片
        self.load_images()

    def load_images(self):
        self.image_combo.clear()
        images = self.scanner.get_unqualified_images()
        for img_path in images:
            self.image_combo.addItem(os.path.basename(img_path), img_path)

        if images:
            self.display_selected_image()

    def display_selected_image(self):
        current_index = self.image_combo.currentIndex()
        if current_index >= 0:
            img_path = self.image_combo.itemData(current_index)
            pixmap = QPixmap(img_path)

            # 缩放图像以适应标签大小
            if not pixmap.isNull():
                scaled_pixmap = pixmap.scaled(
                    self.image_label.size(),
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation
                )
                self.image_label.setPixmap(scaled_pixmap)


class MainWindow(QMainWindow):
    def __init__(self, scanner):
        super().__init__()
        self.scanner = scanner
        self.initUI()

        # 启动摄像头和网络检查定时器
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)  # 约30fps

    def initUI(self):
        self.setWindowTitle('工业流水线PCB分拣系统')
        self.setFixedSize(1000, 600)  # 增加窗口宽度以容纳信息面板

        # 创建堆叠窗口
        self.stacked_widget = QStackedWidget()

        # 欢迎界面
        self.welcome_screen = WelcomeScreen(self)
        self.stacked_widget.addWidget(self.welcome_screen)

        # 登录界面
        self.login_screen = LoginScreen(self)
        self.stacked_widget.addWidget(self.login_screen)

        # 主界面
        self.main_screen = QWidget()
        main_layout = QVBoxLayout()

        # 创建标签页
        self.tab_widget = QTabWidget()

        # 检测标签页
        self.inspection_tab = InspectionTab(self.scanner)
        self.tab_widget.addTab(self.inspection_tab, "PCB检测")

        # 图片查看标签页
        self.image_viewer_tab = ImageViewerTab(self.scanner)
        self.tab_widget.addTab(self.image_viewer_tab, "不合格PCB查看")

        main_layout.addWidget(self.tab_widget)
        self.main_screen.setLayout(main_layout)
        self.stacked_widget.addWidget(self.main_screen)

        # 设置中心窗口
        self.setCentralWidget(self.stacked_widget)

        # 显示欢迎界面
        self.show_welcome_screen()

    def show_welcome_screen(self):
        self.stacked_widget.setCurrentIndex(0)

    def show_login_screen(self):
        self.login_screen = LoginScreen(self)  # 传递self作为main_window参数
        self.stacked_widget.addWidget(self.login_screen)
        self.stacked_widget.setCurrentIndex(1)

    def show_main_screen(self):
        # 连接数据库
        if not self.scanner.connect_db():
            QMessageBox.warning(self, '错误', '无法连接数据库，系统将以有限功能运行！')

        self.stacked_widget.setCurrentIndex(2)

    def update_frame(self):
        # 检查摄像头是否可用
        if self.scanner.cap is None:
            # 尝试重新初始化摄像头
            try:
                self.scanner.cap = cv2.VideoCapture(0)
                if not self.scanner.cap.isOpened():
                    self.scanner.cap = None
                    return
                # 设置较低分辨率
                self.scanner.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 480)
                self.scanner.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 360)
            except:
                self.scanner.cap = None
                return

        # 读取摄像头帧
        ret, frame = self.scanner.cap.read()
        if not ret:
            return

        # 发送帧到服务器
        self.scanner.send_frame(frame)

        # 检查服务器结果
        self.scanner.check_results()

        # 检查原始图片
        self.scanner.check_original_images()

        # 检查处理后图片
        self.scanner.check_processed_images()

        # 刷新数据库信息
        self.scanner.refresh_db_info()

        # 发送串口信号
        self.scanner.send_serial_signals()

        # 更新检测标签页
        self.update_inspection_tab(frame)

    def update_inspection_tab(self, frame):
        # 绘制二维码检测框
        if self.scanner.last_qr_result and 'points' in self.scanner.last_qr_result:
            points = self.scanner.last_qr_result['points']
            n = len(points)
            for i in range(n):
                cv2.line(frame, tuple(points[i]), tuple(points[(i + 1) % n]), (0, 255, 0), 3)

        # 更新检测标签页
        self.inspection_tab.update_frame(frame)

    def closeEvent(self, event):
        # 清理资源
        if self.scanner.cap is not None:
            self.scanner.cap.release()
        if hasattr(self.scanner, 'db') and self.scanner.db.open:
            self.scanner.db.close()
        self.scanner.udp_socket.close()
        self.scanner.result_socket.close()
        self.scanner.original_img_socket.close()
        self.scanner.processed_img_socket.close()

        # 关闭串口
        if self.scanner.serial_port1 and self.scanner.serial_port1.is_open:
            self.scanner.serial_port1.close()
        if self.scanner.serial_port2 and self.scanner.serial_port2.is_open:
            self.scanner.serial_port2.close()
        # 新增：关闭短信串口
        if self.scanner.sms_serial_port and self.scanner.sms_serial_port.is_open:
            self.scanner.sms_serial_port.close()

        # 停止串口监听线程
        if self.scanner.serial_worker:
            self.scanner.serial_worker.stop()
            self.scanner.serial_worker.wait(1000)  # 等待线程结束

        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)

    # 设置应用程序样式
    app.setStyle('Fusion')

    # 创建扫描器实例
    scanner = PCBScannerClient()

    # 创建主窗口
    window = MainWindow(scanner)
    window.show()

    sys.exit(app.exec_())