#ifndef __MOTOR_H
#define __MOTOR_H
#include <sys.h>	 
void TIM4_PWM_Init(u16 arr,u16 psc);
void TIM3_PWM_Init(u16 arr,u16 psc);
#endif
