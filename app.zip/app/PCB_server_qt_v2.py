import sys
import os
import cv2
import numpy as np
import socket
import threading
import json
import time
import logging
import struct
import pymysql
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QPushButton, QTabWidget, QTextEdit, QGroupBox,
                             QComboBox, QFormLayout, QSizePolicy, QScrollArea, QFrame,
                             QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView,
                             QAbstractItemView, QMessageBox)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QThread
from PyQt5.QtGui import QImage, QPixmap, QFont, QColor, QIcon, QBrush, QIntValidator
from ultralytics import YOLO
import torch

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('PCB_Server_GUI')

# 数据库配置
DB_CONFIG = {
    'host': '192.168.201.115',
    'user': 'remote_user',
    'password': '123456',
    'database': 'loognson_pcb',
    'port': 3306,
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}


def resource_path(relative_path):
    """获取资源的绝对路径，支持开发环境和PyInstaller打包环境"""
    try:
        # PyInstaller创建的临时文件夹
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class GUIServer(QThread):
    # 定义信号
    raw_frame_signal = pyqtSignal(np.ndarray)
    processed_frame_signal = pyqtSignal(np.ndarray)
    log_signal = pyqtSignal(str)
    result_signal = pyqtSignal(dict)
    status_signal = pyqtSignal(str)
    stats_signal = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        # ===================== 网络配置 =====================
        self.host = '0.0.0.0'  # 监听所有接口
        self.video_port = 5000  # 视频接收端口
        self.result_port = 5001  # 结果发送端口
        self.original_img_port = 5006  # 原始图片发送端口
        self.processed_img_port = 5007  # 处理后图片发送端口

        # 创建UDP套接字
        self.video_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.video_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)  # 增大缓冲区到1MB
        self.video_socket.bind((self.host, self.video_port))

        self.result_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # 创建原始图片发送套接字
        self.original_img_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        # 创建处理后图片发送套接字
        self.processed_img_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # ===================== 状态变量 =====================
        self.current_frame = None  # 当前原始视频帧
        self.processed_frame = None  # 当前处理后的视频帧
        self.frame_lock = threading.Lock()  # 线程锁
        self.running = True  # 服务器运行标志
        self.last_qr_time = 0  # 上次QR检测时间
        self.qr_cooldown = 1  # 检测冷却时间(秒)
        self.client_address = None  # 客户端地址
        self.last_result = None  # 上次检测结果
        self.detected_pcb_ids = set()  # 记录已检测的PCB ID
        self.current_pcb_id = None  # 当前PCB ID
        self.processing_times = []  # 处理时间列表
        self.last_log_time = 0  # 上次日志时间
        self.frames_received = 0  # 接收的帧数
        self.frames_processed = 0  # 处理的帧数
        self.pcb_detected = 0  # 检测到的PCB数量

        # ===================== QR码检测器 =====================
        self.qr_detector = cv2.QRCodeDetector()  # 使用OpenCV的QRCodeDetector

        # ===================== 加载YOLOv8模型 =====================
        self.log_signal.emit("加载YOLOv8缺陷检测模型...")
        # 使用资源路径函数获取模型路径
        model_path = resource_path("best.pt")
        try:
            self.model = YOLO(model_path)  # 加载预训练模型
            self.model.to("cpu")  # 使用CPU进行推理
            self.log_signal.emit(f"✅ 模型加载成功: {model_path}")
        except Exception as e:
            self.log_signal.emit(f"❌ 模型加载失败: {str(e)}")
            self.model = None

        # 缺陷类别映射
        self.class_map = {
            0: "missing_holes",  # 缺孔
            1: "mouse_bites",  # 鼠咬
            2: "open_circuits",  # 开路
            3: "short_circuits",  # 短路
            4: "stray_signals",  # 杂散信号
            5: "spurious_copper"  # 多余铜
        }

    def detect_defects(self, frame):
        """使用YOLOv8检测PCB缺陷"""
        if self.model is None:
            return frame, {name: 0 for name in self.class_map.values()}

        # 运行模型推理
        results = self.model(frame, device="cpu", verbose=False)

        # 初始化缺陷计数器
        defect_counts = {name: 0 for name in self.class_map.values()}

        # 处理检测结果
        for result in results:
            boxes = result.boxes.xyxy.cpu().numpy()
            classes = result.boxes.cls.cpu().numpy()
            confidences = result.boxes.conf.cpu().numpy()

            for box, cls_id, conf in zip(boxes, classes, confidences):
                x1, y1, x2, y2 = map(int, box)
                class_name = self.class_map.get(int(cls_id), "unknown")
                defect_counts[class_name] += 1

                # 绘制边界框和标签
                color = (0, 255, 0)  # 绿色
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
                label = f"{class_name}: {conf:.2f}"
                cv2.putText(frame, label, (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

        return frame, defect_counts

    def send_images_to_client(self, pcb_id):
        """向客户端发送原始和处理后的图片"""
        if not self.client_address:
            return

        # 获取当前帧
        original_frame = None
        processed_frame = None
        with self.frame_lock:
            if self.current_frame is not None:
                original_frame = self.current_frame.copy()
            if self.processed_frame is not None:
                processed_frame = self.processed_frame.copy()

        # 发送原始图片
        if original_frame is not None:
            # 压缩图片 (降低质量)
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 70]  # 质量设为70
            _, buffer = cv2.imencode('.jpg', original_frame, encode_param)
            data = buffer.tobytes()

            # 添加PCB ID到数据包开头
            pcb_id_bytes = struct.pack('!I', pcb_id)
            packet = pcb_id_bytes + data

            try:
                self.original_img_socket.sendto(packet, (self.client_address[0], self.original_img_port))
                self.log_signal.emit(f"向 {self.client_address[0]}:{self.original_img_port} 发送原始图片 PCB {pcb_id}")
            except Exception as e:
                self.log_signal.emit(f"发送原始图片失败: {e}")

        # 发送处理后的图片
        if processed_frame is not None:
            # 压缩图片 (降低质量)
            encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 70]  # 质量设为70
            _, buffer = cv2.imencode('.jpg', processed_frame, encode_param)
            data = buffer.tobytes()

            # 添加PCB ID到数据包开头
            pcb_id_bytes = struct.pack('!I', pcb_id)
            packet = pcb_id_bytes + data

            try:
                self.processed_img_socket.sendto(packet, (self.client_address[0], self.processed_img_port))
                self.log_signal.emit(
                    f"向 {self.client_address[0]}:{self.processed_img_port} 发送处理后图片 PCB {pcb_id}")
            except Exception as e:
                self.log_signal.emit(f"发送处理后图片失败: {e}")

    def async_detect_defects(self, frame, pcb_id):
        """异步执行缺陷检测"""
        self.log_signal.emit(f"开始检测PCB {pcb_id}的缺陷")
        start_time = time.time()

        try:
            # 执行缺陷检测
            processed_frame, defect_counts = self.detect_defects(frame.copy())

            # 删除图像上添加的PCB ID信息和检测结果
            # 原代码在此处添加文字信息，现已删除

            self.log_signal.emit(f"PCB {pcb_id} 缺陷检测耗时 {(time.time() - start_time):.2f}秒")

            with self.frame_lock:
                self.processed_frame = processed_frame

            # 更新结果
            result_data = {
                "pcb_id": pcb_id,
                "defects": defect_counts,
                "timestamp": time.time()
            }
            self.last_result = result_data
            self.result_signal.emit(result_data)

            # 发送结果
            try:
                json_data = json.dumps(result_data).encode('utf-8')
                self.result_socket.sendto(json_data, self.client_address)
                self.log_signal.emit(f"向客户端发送PCB {pcb_id}的缺陷结果")
            except Exception as e:
                self.log_signal.emit(f"发送缺陷结果失败: {e}")

            # 发送图片到客户端
            self.send_images_to_client(pcb_id)
            self.log_signal.emit(f"向客户端发送PCB {pcb_id}的图片")

        except Exception as e:
            self.log_signal.emit(f"缺陷检测错误: {e}")

    def receive_frames(self):
        """从客户端接收视频帧"""
        self.log_signal.emit(f"UDP视频服务器在端口 {self.video_port} 启动")

        while self.running:
            try:
                # 接收数据包
                data, addr = self.video_socket.recvfrom(65536 * 2)

                # 存储客户端地址
                self.client_address = (addr[0], self.result_port)

                # 解码视频帧
                np_data = np.frombuffer(data, dtype=np.uint8)
                frame = cv2.imdecode(np_data, cv2.IMREAD_COLOR)

                if frame is not None:
                    with self.frame_lock:
                        self.current_frame = frame.copy()
                        # 初始设置处理后的帧为原始帧
                        self.processed_frame = frame.copy()

                    # 发送原始帧信号
                    self.raw_frame_signal.emit(frame)
                    self.frames_received += 1

                    self.log_signal.emit(f"从 {addr} 接收帧")
            except Exception as e:
                self.log_signal.emit(f"接收视频帧错误: {e}")

    def process_frames(self):
        """处理视频帧: 检测QR码和PCB缺陷"""
        self.log_signal.emit("PCB处理引擎启动")

        while self.running:
            start_time = time.time()

            # 添加短暂休眠避免空转
            time.sleep(0.01)

            if self.current_frame is None or not self.client_address:
                continue

            frame = None
            with self.frame_lock:
                frame = self.current_frame.copy()

            current_time = time.time()

            # 检查QR检测冷却时间
            if current_time - self.last_qr_time < self.qr_cooldown:
                continue

            # 使用OpenCV的QRCodeDetector检测二维码
            decoded, points, _ = self.qr_detector.detectAndDecode(frame)
            result_data = {}
            detected_pcb_id = None

            if decoded and points is not None:
                data = decoded.strip()
                points = points[0].astype(int)  # 转换为整数坐标

                if data.isdigit():
                    pcb_id = int(data)

                    if 1 <= pcb_id <= 20:
                        detected_pcb_id = pcb_id
                        # 检查是否是新PCB
                        if detected_pcb_id not in self.detected_pcb_ids:
                            # 新PCB - 添加到已检测集合
                            self.detected_pcb_ids.add(detected_pcb_id)
                            result_data["pcb_id"] = pcb_id
                            result_data["points"] = [tuple(point) for point in points]
                            self.log_signal.emit(f"✅ 检测到新PCB ID: {pcb_id}")
                            self.pcb_detected += 1

                            self.current_pcb_id = pcb_id

                            # 在原始帧上绘制二维码边界
                            n = len(points)
                            for i in range(n):
                                cv2.line(frame, tuple(points[i]), tuple(points[(i + 1) % n]), (0, 255, 0), 3)

                            cv2.putText(frame, f"PCB: {pcb_id}", (10, 30),
                                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

                            # 异步进行缺陷检测
                            threading.Thread(
                                target=self.async_detect_defects,
                                args=(frame.copy(), pcb_id)
                            ).start()
                            self.log_signal.emit(f"启动PCB {pcb_id}的异步缺陷检测")

                            # 更新最后检测时间
                            self.last_qr_time = current_time

                            # 发送初始结果
                            try:
                                result_data["timestamp"] = current_time
                                json_data = json.dumps(result_data).encode('utf-8')
                                self.result_socket.sendto(json_data, self.client_address)
                                self.log_signal.emit(f"向 {self.client_address} 发送初始结果")
                            except Exception as e:
                                self.log_signal.emit(f"发送结果失败: {e}")

                        else:
                            # 已检测过的PCB
                            self.log_signal.emit(f"⚠️ PCB {pcb_id} 已检测过，跳过处理")
                            # 在原始帧上显示提示信息
                            cv2.putText(frame, f"PCB {pcb_id} 已处理", (10, 70),
                                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                            # 更新最后检测时间
                            self.last_qr_time = current_time
                            # 更新processed_frame为当前帧（不进行缺陷检测）
                            with self.frame_lock:
                                self.processed_frame = frame

            # 如果没有检测到有效的PCB ID，更新processed_frame为当前帧
            if not detected_pcb_id:
                with self.frame_lock:
                    self.processed_frame = frame

            # 更新处理后的帧
            if self.processed_frame is not None:
                self.processed_frame_signal.emit(self.processed_frame)
                self.frames_processed += 1

            # 性能监控
            proc_time = time.time() - start_time
            self.processing_times.append(proc_time)

            # 每5秒更新一次统计信息
            if time.time() - self.last_log_time > 5:
                if self.processing_times:
                    avg_time = sum(self.processing_times) / len(self.processing_times)
                    fps = 1 / avg_time if avg_time > 0 else 0
                    stats = f"平均处理时间: {avg_time:.4f}秒, FPS: {fps:.1f}\n" \
                            f"接收帧数: {self.frames_received}, 处理帧数: {self.frames_processed}\n" \
                            f"检测到的PCB数量: {self.pcb_detected}"
                    self.stats_signal.emit(stats)
                self.last_log_time = time.time()

    def run(self):
        """启动服务器主循环"""
        self.status_signal.emit("服务器启动中...")

        # 启动接收线程
        recv_thread = threading.Thread(target=self.receive_frames, daemon=True)
        recv_thread.start()
        self.log_signal.emit("接收线程已启动")

        # 启动处理线程
        process_thread = threading.Thread(target=self.process_frames, daemon=True)
        process_thread.start()
        self.log_signal.emit("处理线程已启动")

        self.status_signal.emit("服务器运行中")
        self.log_signal.emit("✅ PCB缺陷检测服务器已启动")

        # 保持线程运行
        while self.running:
            time.sleep(0.1)

    def stop(self):
        """停止服务器"""
        self.running = False
        self.status_signal.emit("服务器已停止")
        self.log_signal.emit("🛑 PCB缺陷检测服务器已停止")

        # 关闭套接字
        self.video_socket.close()
        self.result_socket.close()
        self.original_img_socket.close()
        self.processed_img_socket.close()
        self.log_signal.emit("网络套接字已关闭")


class VideoDisplayWidget(QLabel):
    """自定义视频显示组件"""

    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("""
            background-color: #2c3e50;
            border: 2px solid #34495e;
            border-radius: 5px;
            color: #ecf0f1;
            font-size: 16px;
        """)
        self.setText(f"{self.title}\n等待视频流...")
        self.setMinimumSize(640, 480)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def set_frame(self, frame):
        """设置显示的帧"""
        if frame is not None:
            # 将OpenCV图像转换为Qt图像
            rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            qt_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qt_image)

            # 缩放图像以适应标签
            self.setPixmap(pixmap.scaled(self.width(), self.height(), Qt.KeepAspectRatio))


class ServerControlPanel(QWidget):
    """服务器控制面板"""

    def __init__(self, server_thread, parent=None):
        super().__init__(parent)
        self.server_thread = server_thread
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # 服务器状态
        status_group = QGroupBox("服务器状态")
        status_layout = QVBoxLayout()

        self.status_label = QLabel("服务器未启动")
        self.status_label.setFont(QFont("Arial", 12, QFont.Bold))
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("padding: 10px;")

        status_layout.addWidget(self.status_label)
        status_group.setLayout(status_layout)

        # 控制按钮
        control_group = QGroupBox("服务器控制")
        control_layout = QHBoxLayout()

        self.start_btn = QPushButton("启动服务器")
        self.start_btn.setIcon(QIcon.fromTheme("media-playback-start"))
        self.start_btn.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
        """)
        self.start_btn.clicked.connect(self.start_server)

        self.stop_btn = QPushButton("停止服务器")
        self.stop_btn.setIcon(QIcon.fromTheme("media-playback-stop"))
        self.stop_btn.setStyleSheet("""
            QPushButton {
                background-color: #c0392b;
                color: white;
                font-weight: bold;
                padding: 10px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #e74c3c;
            }
        """)
        self.stop_btn.clicked.connect(self.stop_server)
        self.stop_btn.setEnabled(False)

        control_layout.addWidget(self.start_btn)
        control_layout.addWidget(self.stop_btn)
        control_group.setLayout(control_layout)

        # 连接信息
        info_group = QGroupBox("连接信息")
        form_layout = QFormLayout()

        self.client_ip = QLabel("无连接")
        self.client_port = QLabel("无连接")
        self.pcb_id = QLabel("无检测")

        form_layout.addRow("客户端 IP:", self.client_ip)
        form_layout.addRow("客户端端口:", self.client_port)
        form_layout.addRow("当前 PCB ID:", self.pcb_id)

        info_group.setLayout(form_layout)

        # 统计信息
        stats_group = QGroupBox("性能统计")
        stats_layout = QVBoxLayout()

        self.stats_label = QLabel("无数据")
        self.stats_label.setAlignment(Qt.AlignLeft)
        self.stats_label.setStyleSheet("font-family: monospace;")

        stats_layout.addWidget(self.stats_label)
        stats_group.setLayout(stats_layout)

        # 添加到主布局
        layout.addWidget(status_group)
        layout.addWidget(control_group)
        layout.addWidget(info_group)
        layout.addWidget(stats_group)
        layout.addStretch(1)

        self.setLayout(layout)

    def start_server(self):
        """启动服务器"""
        if not self.server_thread.isRunning():
            self.server_thread.start()
            self.start_btn.setEnabled(False)
            self.stop_btn.setEnabled(True)

    def stop_server(self):
        """停止服务器"""
        if self.server_thread.isRunning():
            self.server_thread.stop()
            self.start_btn.setEnabled(True)
            self.stop_btn.setEnabled(False)

    def update_status(self, status):
        """更新服务器状态"""
        self.status_label.setText(status)

        # 根据状态改变颜色
        if "运行" in status:
            self.status_label.setStyleSheet("background-color: #27ae60; color: white; padding: 10px;")
        elif "停止" in status:
            self.status_label.setStyleSheet("background-color: #c0392b; color: white; padding: 10px;")
        else:
            self.status_label.setStyleSheet("background-color: #f39c12; color: white; padding: 10px;")

    def update_stats(self, stats):
        """更新性能统计"""
        self.stats_label.setText(stats)

    def update_connection(self, ip, port):
        """更新连接信息"""
        self.client_ip.setText(ip)
        self.client_port.setText(str(port))

    def update_pcb_id(self, pcb_id):
        """更新PCB ID"""
        self.pcb_id.setText(str(pcb_id))


class ResultDisplayWidget(QWidget):
    """结果显示组件"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()

    def initUI(self):
        layout = QVBoxLayout()

        # 结果标题
        result_title = QLabel("检测结果")
        result_title.setFont(QFont("Arial", 14, QFont.Bold))
        result_title.setAlignment(Qt.AlignCenter)
        result_title.setStyleSheet("padding: 10px; background-color: #34495e; color: white;")

        # 结果详情
        self.result_details = QTextEdit()
        self.result_details.setReadOnly(True)
        self.result_details.setStyleSheet("""
            QTextEdit {
                background-color: #2c3e50;
                color: #ecf0f1;
                border: 1px solid #34495e;
                border-radius: 3px;
                font-family: monospace;
                font-size: 14px;
            }
        """)

        layout.addWidget(result_title)
        layout.addWidget(self.result_details)

        self.setLayout(layout)

    def update_result(self, result_data):
        """更新检测结果"""
        if not result_data:
            return

        pcb_id = result_data.get("pcb_id", "N/A")
        defects = result_data.get("defects", {})
        timestamp = result_data.get("timestamp", 0)

        # 格式化时间
        time_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(timestamp))

        # 计算总缺陷数
        total_defects = sum(defects.values())

        # 确定PCB是否合格
        is_qualified = all(count == 0 for count in defects.values())
        status = "合格" if is_qualified else "不合格"
        status_color = "#27ae60" if is_qualified else "#e74c3c"

        # 构建结果字符串
        result_text = f"PCB ID: {pcb_id}\n"
        result_text += f"检测时间: {time_str}\n"
        result_text += f"状态: <span style='color:{status_color}; font-weight:bold'>{status}</span>\n"
        result_text += f"总缺陷数: {total_defects}\n\n"
        result_text += "缺陷详情:\n"

        for defect, count in defects.items():
            result_text += f"  {defect.replace('_', ' ').title()}: {count}\n"

        self.result_details.setHtml(result_text)


class DatabaseQueryTab(QWidget):
    """数据库查询标签页"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.initUI()
        self.db_connection = None
        self.connect_db()

    def initUI(self):
        layout = QVBoxLayout()

        # 查询面板
        query_group = QGroupBox("PCB数据库查询")
        query_layout = QFormLayout()

        # PCB ID输入
        self.pcb_id_input = QLineEdit()
        self.pcb_id_input.setPlaceholderText("输入PCB ID (1-20)")
        self.pcb_id_input.setValidator(QIntValidator(1, 20))
        self.pcb_id_input.setStyleSheet("""
            QLineEdit {
                padding: 8px;
                border: 1px solid #3498db;
                border-radius: 4px;
                font-size: 14px;
            }
        """)

        # 查询按钮
        self.query_btn = QPushButton("查询")
        self.query_btn.setIcon(QIcon.fromTheme("system-search"))
        self.query_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 8px 15px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)
        self.query_btn.clicked.connect(self.query_pcb_info)

        # 添加行
        query_layout.addRow("PCB ID:", self.pcb_id_input)
        query_layout.addRow(self.query_btn)
        query_group.setLayout(query_layout)

        # 结果表格
        result_group = QGroupBox("查询结果")
        result_layout = QVBoxLayout()

        # 创建表格
        self.result_table = QTableWidget()
        self.result_table.setColumnCount(10)
        # 修正列名：将"贷款信号"改为"杂散信号"
        self.result_table.setHorizontalHeaderLabels([
            "PCB ID", "生产时间", "检测时间", "缺孔", "鼠咬", "开路",
            "短路", "杂散信号", "多余铜", "合格状态"
        ])

        # 设置表格属性
        self.result_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.result_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.result_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.result_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.result_table.verticalHeader().setVisible(False)
        self.result_table.setStyleSheet("""
            QTableWidget {
                background-color: #2c3e50;
                color: #ecf0f1;
                gridline-color: #34495e;
                font-size: 12px;
            }
            QHeaderView::section {
                background-color: #34495e;
                color: white;
                padding: 4px;
                border: none;
                font-weight: bold;
            }
        """)

        # 添加表格到布局
        result_layout.addWidget(self.result_table)
        result_group.setLayout(result_layout)

        # 添加到主布局
        layout.addWidget(query_group)
        layout.addWidget(result_group, 1)

        self.setLayout(layout)

    def connect_db(self):
        """连接数据库"""
        try:
            self.db_connection = pymysql.connect(**DB_CONFIG)
            self.show_message("✅ 数据库连接成功", "#27ae60")
        except pymysql.Error as e:
            self.show_message(f"❌ 数据库连接失败: {e}", "#e74c3c")
            self.db_connection = None
        except Exception as e:
            self.show_message(f"❌ 数据库连接错误: {e}", "#e74c3c")
            self.db_connection = None

    def query_pcb_info(self):
        """查询PCB信息"""
        # 检查数据库连接是否有效
        if not self.db_connection or not self.db_connection.open:
            try:
                self.db_connection = pymysql.connect(**DB_CONFIG)
                self.show_message("✅ 重新连接数据库成功", "#27ae60")
            except Exception as e:
                self.show_message(f"❌ 数据库连接失败: {e}", "#e74c3c")
                self.db_connection = None
                return

        pcb_id = self.pcb_id_input.text()
        if not pcb_id:
            self.show_message("⚠️ 请输入PCB ID", "#f39c12")
            return

        try:
            with self.db_connection.cursor() as cursor:
                sql = """
                    SELECT 
                        pcb_id, 
                        DATE_FORMAT(production_time, '%Y-%m-%d %H:%i') AS production_time,
                        DATE_FORMAT(inspection_time, '%Y-%m-%d %H:%i') AS inspection_time,
                        missing_holes,
                        mouse_bites,
                        open_circuits,
                        short_circuits,
                        stray_signals,
                        spurious_copper,
                        is_qualified
                    FROM pcb_inspection
                    WHERE pcb_id = %s
                """
                cursor.execute(sql, (pcb_id,))
                result = cursor.fetchone()

                if result:
                    self.display_result(result)
                    self.show_message(f"✅ 成功查询到PCB {pcb_id}的信息", "#27ae60")
                else:
                    self.show_message(f"⚠️ 未找到PCB {pcb_id}的信息", "#f39c12")
        except pymysql.Error as e:
            self.show_message(f"❌ 数据库查询失败: {e}", "#e74c3c")
        except Exception as e:
            self.show_message(f"❌ 查询错误: {e}", "#e74c3c")

    def display_result(self, result):
        """在表格中显示查询结果"""
        # 清空表格
        self.result_table.setRowCount(0)

        # 添加一行
        self.result_table.setRowCount(1)

        # 填充数据
        row = 0
        self.result_table.setItem(row, 0, QTableWidgetItem(str(result['pcb_id'])))
        self.result_table.setItem(row, 1, QTableWidgetItem(result['production_time'] or "N/A"))
        self.result_table.setItem(row, 2, QTableWidgetItem(result['inspection_time'] or "N/A"))
        self.result_table.setItem(row, 3, QTableWidgetItem(str(result['missing_holes'])))
        self.result_table.setItem(row, 4, QTableWidgetItem(str(result['mouse_bites'])))
        self.result_table.setItem(row, 5, QTableWidgetItem(str(result['open_circuits'])))
        self.result_table.setItem(row, 6, QTableWidgetItem(str(result['short_circuits'])))
        self.result_table.setItem(row, 7, QTableWidgetItem(str(result['stray_signals'])))
        self.result_table.setItem(row, 8, QTableWidgetItem(str(result['spurious_copper'])))

        # 合格状态
        is_qualified = result['is_qualified']
        status_item = QTableWidgetItem("合格" if is_qualified else "不合格")
        status_item.setBackground(QBrush(QColor("#27ae60") if is_qualified else QColor("#e74c3c")))
        status_item.setForeground(QBrush(Qt.white))
        self.result_table.setItem(row, 9, status_item)

    def show_message(self, message, color):
        """在状态栏显示消息"""
        self.result_table.setRowCount(0)
        self.result_table.setRowCount(1)
        # 转义消息中的百分号
        escaped_message = message.replace('%', '%%')
        item = QTableWidgetItem(escaped_message)
        item.setForeground(QBrush(QColor(color)))
        item.setTextAlignment(Qt.AlignCenter)
        self.result_table.setItem(0, 0, item)
        self.result_table.setSpan(0, 0, 1, self.result_table.columnCount())


class ServerMainWindow(QMainWindow):
    """服务器主窗口"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("PCB缺陷检测服务器")
        self.setGeometry(100, 100, 1200, 800)

        # 创建服务器线程
        self.server_thread = GUIServer()

        # 连接信号
        self.server_thread.raw_frame_signal.connect(self.update_raw_video)
        self.server_thread.processed_frame_signal.connect(self.update_processed_video)
        self.server_thread.log_signal.connect(self.update_log)
        self.server_thread.result_signal.connect(self.update_result)
        self.server_thread.status_signal.connect(self.update_status)
        self.server_thread.stats_signal.connect(self.update_stats)

        self.initUI()

    def initUI(self):
        # 主布局
        main_widget = QWidget()
        main_layout = QHBoxLayout(main_widget)

        # 左侧面板 (控制面板和日志)
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)

        # 控制面板
        self.control_panel = ServerControlPanel(self.server_thread)

        # 日志区域
        log_group = QGroupBox("服务器日志")
        log_layout = QVBoxLayout()

        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("""
            QTextEdit {
                background-color: #1a1a2e;
                color: #e6e6e6;
                border: 1px solid #34495e;
                border-radius: 3px;
                font-family: monospace;
                font-size: 12px;
            }
        """)

        log_layout.addWidget(self.log_area)
        log_group.setLayout(log_layout)

        # 添加到左侧布局
        left_layout.addWidget(self.control_panel)
        left_layout.addWidget(log_group)

        # 右侧面板 (视频、结果和数据库)
        right_panel = QTabWidget()

        # 视频标签页
        video_tab = QWidget()
        video_layout = QVBoxLayout(video_tab)

        # 原始视频显示
        raw_group = QGroupBox("原始视频流")
        raw_layout = QVBoxLayout()

        self.raw_video = VideoDisplayWidget("原始视频")

        raw_layout.addWidget(self.raw_video)
        raw_group.setLayout(raw_layout)

        # 处理后视频显示
        processed_group = QGroupBox("处理后视频")
        processed_layout = QVBoxLayout()

        self.processed_video = VideoDisplayWidget("处理后视频")

        processed_layout.addWidget(self.processed_video)
        processed_group.setLayout(processed_layout)

        video_layout.addWidget(raw_group)
        video_layout.addWidget(processed_group)

        # 结果标签页
        result_tab = QWidget()
        result_layout = QVBoxLayout(result_tab)

        # 结果详情
        self.result_display = ResultDisplayWidget()

        # 系统信息
        info_group = QGroupBox("系统信息")
        info_layout = QFormLayout()

        self.py_version = QLabel(f"{sys.version.split()[0]}")
        self.qt_version = QLabel(f"{QApplication.instance().applicationVersion()}")
        self.opencv_version = QLabel(f"{cv2.__version__}")
        self.pytorch_version = QLabel(f"{torch.__version__}")

        info_layout.addRow("Python 版本:", self.py_version)
        info_layout.addRow("PyQt5 版本:", self.qt_version)
        info_layout.addRow("OpenCV 版本:", self.opencv_version)
        info_layout.addRow("PyTorch 版本:", self.pytorch_version)

        info_group.setLayout(info_layout)

        result_layout.addWidget(self.result_display)
        result_layout.addWidget(info_group)

        # 数据库查询标签页
        self.db_query_tab = DatabaseQueryTab()

        # 添加到右侧标签页
        right_panel.addTab(video_tab, "视频监控")
        right_panel.addTab(result_tab, "检测结果")
        right_panel.addTab(self.db_query_tab, "数据库查询")

        # 添加到主布局
        main_layout.addWidget(left_panel, 1)
        main_layout.addWidget(right_panel, 2)

        self.setCentralWidget(main_widget)

        # 状态栏
        self.statusBar().showMessage("就绪")

        # 设置样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #2c3e50;
            }
            QGroupBox {
                font-weight: bold;
                font-size: 14px;
                color: #ecf0f1;
                border: 1px solid #34495e;
                border-radius: 5px;
                margin-top: 1ex;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top center;
                padding: 0 5px;
                background-color: #34495e;
            }
            QLabel {
                color: #ecf0f1;
            }
            QTabWidget::pane {
                border: 1px solid #34495e;
                border-radius: 3px;
                background: #2c3e50;
            }
            QTabBar::tab {
                background: #34495e;
                color: #ecf0f1;
                padding: 8px 20px;
                border-top-left-radius: 3px;
                border-top-right-radius: 3px;
            }
            QTabBar::tab:selected {
                background: #3498db;
            }
            QLineEdit {
                background-color: #2c3e50;
                color: #ecf0f1;
                border: 1px solid #3498db;
                border-radius: 4px;
                padding: 5px;
            }
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 4px;
                padding: 5px 10px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
        """)

    def update_raw_video(self, frame):
        """更新原始视频显示"""
        self.raw_video.set_frame(frame)

    def update_processed_video(self, frame):
        """更新处理后视频显示"""
        self.processed_video.set_frame(frame)

    def update_log(self, message):
        """更新日志区域"""
        timestamp = time.strftime("%H:%M:%S", time.localtime())
        self.log_area.append(f"[{timestamp}] {message}")
        self.log_area.verticalScrollBar().setValue(self.log_area.verticalScrollBar().maximum())

        # 在状态栏显示最后一条消息
        self.statusBar().showMessage(message)

    def update_result(self, result_data):
        """更新结果显示"""
        self.result_display.update_result(result_data)

        # 更新PCB ID显示
        pcb_id = result_data.get("pcb_id", "N/A")
        self.control_panel.update_pcb_id(pcb_id)

    def update_status(self, status):
        """更新服务器状态"""
        self.control_panel.update_status(status)

    def update_stats(self, stats):
        """更新性能统计"""
        self.control_panel.update_stats(stats)

    def closeEvent(self, event):
        """关闭窗口时停止服务器"""
        if self.server_thread.isRunning():
            self.server_thread.stop()
            self.server_thread.wait(2000)  # 等待2秒

        event.accept()


def main():
    app = QApplication(sys.argv)

    # 设置应用程序图标
    try:
        icon_path = resource_path("pcb_icon.ico")
        app.setWindowIcon(QIcon(icon_path))
    except:
        pass  # 如果图标不存在则忽略

    # 设置应用程序样式
    app.setStyle("Fusion")

    window = ServerMainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()